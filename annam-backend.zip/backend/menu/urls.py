from django.urls import path
from . import views

urlpatterns = [
    path('categories/', views.CategoryListView.as_view(), name='menu-categories'),
    path('featured/', views.FeaturedItemsView.as_view(), name='menu-featured'),
]
