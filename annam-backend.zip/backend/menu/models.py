from django.db import models


class Category(models.Model):
    """
    Powers both the Home page 'Popular Categories' cards and the Offer
    page tabs (Combo / Gravy / Kulambu / Sea food / Desert).
    """
    name = models.CharField(max_length=80)
    slug = models.SlugField(unique=True, help_text="Used in the Offer page tab, e.g. 'gravy', 'seafood'")
    image_url = models.URLField(blank=True, help_text="Image shown on the Home page category card")
    sort_order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['sort_order', 'name']
        verbose_name_plural = 'Categories'

    def __str__(self):
        return self.name


class MenuItem(models.Model):
    BADGE_CHOICES = [
        ('off', '% OFF'),
        ('discount', '% DISCOUNT'),
        ('', 'No badge'),
    ]

    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='items')
    name = models.CharField(max_length=120)
    price = models.DecimalField(max_digits=8, decimal_places=2)
    image_url = models.URLField(blank=True)
    rating = models.PositiveSmallIntegerField(default=4, help_text="Stars shown on Home page food cards (0-5)")
    badge_type = models.CharField(max_length=10, choices=BADGE_CHOICES, blank=True)
    badge_text = models.CharField(max_length=30, blank=True, help_text="e.g. '50% OFF' or '25% DISCOUNT'")
    is_featured = models.BooleanField(default=False, help_text="Show on Home page 'Popular Food Items'")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['category', 'name']

    def __str__(self):
        return f"{self.name} ({self.category.name})"
