from rest_framework.generics import ListAPIView
from .models import Category, MenuItem
from .serializers import CategorySerializer, MenuItemSerializer


class CategoryListView(ListAPIView):
    """
    GET /api/menu/categories/
    Returns every category with its items nested inside — this is what
    powers the Offer page tabs (each category = one tab/panel).
    """
    queryset = Category.objects.prefetch_related('items').all()
    serializer_class = CategorySerializer


class FeaturedItemsView(ListAPIView):
    """
    GET /api/menu/featured/
    Returns items flagged is_featured=True — this is what powers the
    Home page 'Popular Food Items' section.
    """
    queryset = MenuItem.objects.filter(is_featured=True, is_active=True)
    serializer_class = MenuItemSerializer
