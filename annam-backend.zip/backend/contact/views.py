from rest_framework.generics import CreateAPIView
from .models import ContactMessage
from .serializers import ContactMessageSerializer


class ContactMessageCreateView(CreateAPIView):
    """
    POST /api/contact/
    body: { full_name, email, phone, subject, message }
    Anyone can submit — no login required, matching the public contact form.
    Messages show up in Django admin at /admin/contact/contactmessage/
    """
    queryset = ContactMessage.objects.all()
    serializer_class = ContactMessageSerializer
